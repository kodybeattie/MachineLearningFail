class Road(object):
    """This is a class that represents a roadway"""
    upVertStopPoints = [510]
    downVertStopPoints = [613]
    rightHoriStopPoints = [50, 627, 1359]
    leftHoriStopPoints = [150,728,1457]
    def __init__(self):
        pass


