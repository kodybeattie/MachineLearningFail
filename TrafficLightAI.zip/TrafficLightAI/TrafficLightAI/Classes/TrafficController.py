class TrafficController(object):
    """description of class"""


